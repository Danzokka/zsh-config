[Appearance]
ColorScheme=Breeze
Font=Adwaita Mono,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Command=/bin/zsh
Name=zsh-starship
Parent=FALLBACK/

[Scrolling]
ScrollBarPosition=2
